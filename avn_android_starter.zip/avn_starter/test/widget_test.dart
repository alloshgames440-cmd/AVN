import 'package:flutter_test/flutter_test.dart';
import 'package:avn_app/app.dart';

void main() {
  testWidgets('AVN login screen renders the brand and invite-only message',
      (tester) async {
    await tester.pumpWidget(const AvnApp());

    expect(find.text('AURA VELOX NEXA'), findsOneWidget);
    expect(find.text('تسجيل الدخول'), findsOneWidget);
    expect(find.textContaining('التسجيل مغلق'), findsOneWidget);
  });
}
