import 'package:flutter/material.dart';

import 'core/theme/avn_theme.dart';
import 'features/auth/presentation/login_screen.dart';

class AvnApp extends StatelessWidget {
  const AvnApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AVN — Aura Velox NEXA',
      debugShowCheckedModeBanner: false,
      theme: AvnTheme.dark(),
      home: const LoginScreen(),
    );
  }
}
