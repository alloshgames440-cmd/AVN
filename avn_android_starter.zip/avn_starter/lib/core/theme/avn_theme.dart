import 'package:flutter/material.dart';

abstract final class AvnColors {
  static const background = Color(0xFF090909);
  static const surface = Color(0xFF141414);
  static const surfaceRaised = Color(0xFF1C1C1C);
  static const red = Color(0xFFD71935);
  static const darkRed = Color(0xFF650B19);
  static const grey = Color(0xFF929292);
  static const white = Color(0xFFF5F5F5);
  static const border = Color(0xFF303030);
}

abstract final class AvnTheme {
  static ThemeData dark() {
    final colorScheme = const ColorScheme.dark(
      primary: AvnColors.red,
      secondary: AvnColors.darkRed,
      surface: AvnColors.surface,
      error: Color(0xFFFF596B),
      onPrimary: Colors.white,
      onSecondary: Colors.white,
      onSurface: AvnColors.white,
      onError: Colors.white,
    );

    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: AvnColors.background,
      fontFamily: null,
      textTheme: const TextTheme(
        headlineLarge: TextStyle(
          color: AvnColors.white,
          fontSize: 30,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.5,
        ),
        headlineMedium: TextStyle(
          color: AvnColors.white,
          fontSize: 23,
          fontWeight: FontWeight.w700,
        ),
        titleLarge: TextStyle(
          color: AvnColors.white,
          fontSize: 18,
          fontWeight: FontWeight.w700,
        ),
        bodyLarge: TextStyle(color: AvnColors.white, fontSize: 15),
        bodyMedium: TextStyle(color: AvnColors.grey, fontSize: 13),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AvnColors.surface,
        hintStyle: const TextStyle(color: AvnColors.grey),
        labelStyle: const TextStyle(color: AvnColors.grey),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 17,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AvnColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AvnColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AvnColors.red, width: 1.4),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: AvnColors.red,
          foregroundColor: Colors.white,
          disabledBackgroundColor: AvnColors.darkRed.withValues(alpha: 0.45),
          disabledForegroundColor: Colors.white54,
          minimumSize: const Size.fromHeight(54),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          textStyle: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
      dividerColor: AvnColors.border,
    );
  }
}
