import 'package:flutter/material.dart';

import '../../../core/theme/avn_theme.dart';
import '../../../shared/widgets/avn_mark.dart';
import '../../home/presentation/preview_shell.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _memberIdController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _obscurePassword = true;

  @override
  void dispose() {
    _memberIdController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _showBackendNotice() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'تسجيل الدخول غير مفعّل بعد. سنربطه بـ Supabase قبل السماح بالدخول.',
          textDirection: TextDirection.rtl,
        ),
      ),
    );
  }

  void _openDesignPreview() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => const PreviewShell(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 28),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 430),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const SizedBox(height: 18),
                    const Center(child: AvnMark(size: 92)),
                    const SizedBox(height: 25),
                    const Text(
                      'AURA VELOX NEXA',
                      textAlign: TextAlign.center,
                      textDirection: TextDirection.ltr,
                      style: TextStyle(
                        color: AvnColors.white,
                        fontSize: 19,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 2.2,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'مساحة خاصة. عضوية بالدعوة فقط.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AvnColors.grey, fontSize: 13),
                    ),
                    const SizedBox(height: 38),
                    const Text(
                      'تسجيل الدخول',
                      style: TextStyle(
                        color: AvnColors.white,
                        fontSize: 23,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 7),
                    const Text(
                      'أدخل بيانات عضويتك للوصول إلى AVN.',
                      style: TextStyle(color: AvnColors.grey, fontSize: 13),
                    ),
                    const SizedBox(height: 24),
                    TextField(
                      controller: _memberIdController,
                      textDirection: TextDirection.ltr,
                      textAlign: TextAlign.left,
                      autocorrect: false,
                      decoration: const InputDecoration(
                        labelText: 'معرّف العضو',
                        hintText: 'AVN-0001',
                        prefixIcon: Icon(Icons.badge_outlined),
                      ),
                    ),
                    const SizedBox(height: 14),
                    TextField(
                      controller: _passwordController,
                      obscureText: _obscurePassword,
                      decoration: InputDecoration(
                        labelText: 'كلمة المرور',
                        prefixIcon: const Icon(Icons.lock_outline),
                        suffixIcon: IconButton(
                          onPressed: () => setState(
                            () => _obscurePassword = !_obscurePassword,
                          ),
                          icon: Icon(
                            _obscurePassword
                                ? Icons.visibility_outlined
                                : Icons.visibility_off_outlined,
                          ),
                          tooltip: _obscurePassword
                              ? 'إظهار كلمة المرور'
                              : 'إخفاء كلمة المرور',
                        ),
                      ),
                    ),
                    const SizedBox(height: 22),
                    FilledButton(
                      onPressed: _showBackendNotice,
                      child: const Text('تسجيل الدخول'),
                    ),
                    const SizedBox(height: 18),
                    Container(
                      padding: const EdgeInsets.all(13),
                      decoration: BoxDecoration(
                        color: AvnColors.surface,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: AvnColors.border),
                      ),
                      child: const Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(
                            Icons.shield_outlined,
                            color: AvnColors.red,
                            size: 19,
                          ),
                          SizedBox(width: 9),
                          Expanded(
                            child: Text(
                              'التسجيل مغلق. لا يمكن إنشاء حساب دون دعوة وموافقة الإدارة.',
                              style: TextStyle(
                                color: AvnColors.grey,
                                fontSize: 12,
                                height: 1.55,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    TextButton(
                      onPressed: _openDesignPreview,
                      child: const Text(
                        'معاينة التصميم فقط',
                        style: TextStyle(color: AvnColors.white),
                      ),
                    ),
                    const SizedBox(height: 26),
                    const Text(
                      'AVN  •  PRIVATE MEMBER NETWORK',
                      textAlign: TextAlign.center,
                      textDirection: TextDirection.ltr,
                      style: TextStyle(
                        color: Color(0xFF656565),
                        fontSize: 9,
                        letterSpacing: 1.1,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
