import 'package:flutter/material.dart';

import '../../../core/theme/avn_theme.dart';
import '../../../shared/widgets/avn_mark.dart';

class PreviewShell extends StatefulWidget {
  const PreviewShell({super.key});

  @override
  State<PreviewShell> createState() => _PreviewShellState();
}

class _PreviewShellState extends State<PreviewShell> {
  int _selectedIndex = 0;

  static const _titles = ['الرئيسية', 'المهام', 'القنوات', 'الملف الشخصي'];
  static const _icons = [
    Icons.grid_view_rounded,
    Icons.task_alt_rounded,
    Icons.graphic_eq_rounded,
    Icons.person_outline_rounded,
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: AvnColors.background,
          titleSpacing: 18,
          title: Row(
            children: [
              const AvnMark(size: 34),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'AVN',
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontSize: 16,
                      letterSpacing: 1.3,
                    ),
                  ),
                  Text(
                    _titles[_selectedIndex],
                    style: const TextStyle(
                      color: AvnColors.grey,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        body: SafeArea(
          child: Column(
            children: [
              Container(
                width: double.infinity,
                margin: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFF241015),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AvnColors.darkRed),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.visibility_outlined,
                        color: AvnColors.red, size: 18),
                    SizedBox(width: 9),
                    Expanded(
                      child: Text(
                        'وضع معاينة التصميم — لا توجد جلسة عضوية أو بيانات حقيقية.',
                        style: TextStyle(
                          color: AvnColors.white,
                          fontSize: 11,
                          height: 1.45,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(child: _buildCurrentPage()),
            ],
          ),
        ),
        bottomNavigationBar: NavigationBar(
          backgroundColor: AvnColors.surface,
          indicatorColor: AvnColors.darkRed.withValues(alpha: 0.7),
          selectedIndex: _selectedIndex,
          onDestinationSelected: (index) {
            setState(() => _selectedIndex = index);
          },
          destinations: List.generate(
            _titles.length,
            (index) => NavigationDestination(
              icon: Icon(_icons[index]),
              label: _titles[index],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCurrentPage() {
    switch (_selectedIndex) {
      case 0:
        return const _HomePreviewPage();
      case 1:
        return const _EmptyFeaturePage(
          icon: Icons.task_alt_rounded,
          title: 'المهام',
          description: 'سيتم ربط المهام بقاعدة البيانات وسجل التغييرات في مرحلة المهام.',
        );
      case 2:
        return const _EmptyFeaturePage(
          icon: Icons.graphic_eq_rounded,
          title: 'القنوات الصوتية',
          description: 'لن تظهر قنوات أو اتصالات فعلية قبل إعداد LiveKit والتحقق من الصلاحيات.',
        );
      default:
        return const _EmptyFeaturePage(
          icon: Icons.person_outline_rounded,
          title: 'الملف الشخصي',
          description: 'ستظهر بيانات العضو بعد تفعيل الحسابات والدعوات.',
        );
    }
  }
}

class _HomePreviewPage extends StatelessWidget {
  const _HomePreviewPage();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 10, 18, 24),
      children: [
        const Text(
          'مرحباً بك في AVN',
          style: TextStyle(
            color: AvnColors.white,
            fontSize: 24,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 6),
        const Text(
          'مركزك الخاص لمتابعة العضوية والمهام والتواصل.',
          style: TextStyle(color: AvnColors.grey, fontSize: 13),
        ),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(17),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: const LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [Color(0xFF38121A), Color(0xFF171010)],
            ),
            border: Border.all(color: AvnColors.darkRed),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'حالة النظام',
                style: TextStyle(color: Colors.white70, fontSize: 12),
              ),
              SizedBox(height: 8),
              Row(
                children: [
                  Icon(Icons.pending_outlined, color: AvnColors.red),
                  SizedBox(width: 8),
                  Text(
                    'قيد الإعداد',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w800,
                      fontSize: 20,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 7),
              Text(
                'سيتم تحديث الحالة من الخادم بعد إكمال المصادقة.',
                style: TextStyle(color: Colors.white70, fontSize: 11),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        const Text(
          'نظرة عامة',
          style: TextStyle(
            color: AvnColors.white,
            fontSize: 17,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 12),
        const Row(
          children: [
            Expanded(
              child: _MetricCard(
                label: 'الأعضاء النشطون',
                value: '—',
                icon: Icons.groups_outlined,
              ),
            ),
            SizedBox(width: 10),
            Expanded(
              child: _MetricCard(
                label: 'المهام الحالية',
                value: '—',
                icon: Icons.assignment_outlined,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        const Row(
          children: [
            Expanded(
              child: _MetricCard(
                label: 'المهام المكتملة',
                value: '—',
                icon: Icons.task_alt_outlined,
              ),
            ),
            SizedBox(width: 10),
            Expanded(
              child: _MetricCard(
                label: 'رصيد المحفظة',
                value: '—',
                icon: Icons.account_balance_wallet_outlined,
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: AvnColors.surface,
            borderRadius: BorderRadius.circular(15),
            border: Border.all(color: AvnColors.border),
          ),
          child: const Row(
            children: [
              Icon(Icons.info_outline, color: AvnColors.red),
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  'هذه شاشة تصميم أولية. الأرقام والبيانات غير متاحة حالياً، ولم يتم إدخال بيانات تجريبية على أنها حقيقية.',
                  style: TextStyle(
                    color: AvnColors.grey,
                    fontSize: 11,
                    height: 1.5,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({
    required this.label,
    required this.value,
    required this.icon,
  });

  final String label;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AvnColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AvnColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: AvnColors.red, size: 20),
          const SizedBox(height: 14),
          Text(
            value,
            style: const TextStyle(
              color: AvnColors.white,
              fontSize: 23,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: const TextStyle(color: AvnColors.grey, fontSize: 11),
          ),
        ],
      ),
    );
  }
}

class _EmptyFeaturePage extends StatelessWidget {
  const _EmptyFeaturePage({
    required this.icon,
    required this.title,
    required this.description,
  });

  final IconData icon;
  final String title;
  final String description;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AvnColors.surface,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: AvnColors.darkRed),
              ),
              child: Icon(icon, color: AvnColors.red, size: 34),
            ),
            const SizedBox(height: 18),
            Text(
              title,
              style: const TextStyle(
                color: AvnColors.white,
                fontSize: 20,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 9),
            Text(
              description,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: AvnColors.grey,
                fontSize: 13,
                height: 1.6,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
