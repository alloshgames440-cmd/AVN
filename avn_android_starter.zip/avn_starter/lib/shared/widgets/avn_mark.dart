import 'package:flutter/material.dart';

import '../../core/theme/avn_theme.dart';

class AvnMark extends StatelessWidget {
  const AvnMark({super.key, this.size = 82});

  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * 0.25),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF242424), Color(0xFF101010)],
        ),
        border: Border.all(color: AvnColors.darkRed, width: 1.2),
        boxShadow: [
          BoxShadow(
            color: AvnColors.red.withValues(alpha: 0.13),
            blurRadius: 28,
            spreadRadius: 1,
          ),
        ],
      ),
      alignment: Alignment.center,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Positioned(
            top: size * 0.13,
            child: Container(
              width: size * 0.48,
              height: 2,
              color: AvnColors.red.withValues(alpha: 0.75),
            ),
          ),
          Text(
            'AVN',
            style: TextStyle(
              color: Colors.white,
              fontSize: size * 0.27,
              fontWeight: FontWeight.w900,
              letterSpacing: -1.5,
            ),
          ),
          Positioned(
            bottom: size * 0.14,
            child: Container(
              width: size * 0.28,
              height: 3,
              decoration: BoxDecoration(
                color: AvnColors.red,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
